# 🌐 Moba InfoTech - Web Design & Development

A responsive **Web Design & Development** project with **Day/Night Mode** and modern UI.  
This project is created to demonstrate web designing concepts like **HTML, CSS, JavaScript** along with a professional look.

---

## ✨ Features
- 🌙 **Day & Night Mode** toggle  
- 📱 Fully responsive (works on **mobile & laptop**)  
- 🎨 Modern UI with neon green theme  
- 📚 Complete training modules  
- 💻 Live projects section  
- 🎥 Video tutorials  
- 👨‍🏫 Expert guidance  
- 🌐 Job-oriented skills section  

---

## 🚀 Technologies Used
- **HTML5**
- **CSS3**
- **JavaScript**
- Responsive Design

---

## 📷 Preview
![Website Screenshot](https://via.placeholder.com/900x500?text=Moba+InfoTech+Website+Preview)

---

## 🛠 How to View
1. Visit the repository link.  
2. Open the hosted website using **GitHub Pages**.  

🔗 Example: `https://your-username.github.io/moba-infotech/`

---

## 📩 Contact
For queries & feedback:  
📧 Email: info@mobainfotech.com  
🌐 Website: [Moba InfoTech](#)

---

© 2025 Moba InfoTech. All rights reserved.
